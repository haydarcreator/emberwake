# Emberwake

A 2D arena survival game for 1 to 4 players, with its website, sign-in and
multiplayer server. Plain HTML, CSS and JavaScript. No build step, no
dependencies.

## Play

```
node server.js
```

Open http://localhost:8080. The server also prints a network address
(for example http://192.168.1.20:8080) that other devices on the same Wi-Fi
can open to join your games.

## What's inside

```
index.html          Website: features, modes, install guide, FAQ
play.html           The game
account.html        Player profile and stats (sign-in required)
privacy.html        Privacy Policy
terms.html          Terms of Use
server.js           Web server + multiplayer rooms over WebSocket (/ws)
shared/sim.js       Game rules, shared by the browser and the server
js/game/            Renderer, audio, input, networking, menus and game loop
js/auth.js          Sign-in (Firebase: Google, email + password)
js/auth-config.js   Firebase settings
js/profile.js       Player name and stats (saved in the browser)
js/pwa.js, sw.js    Installable app + offline support
manifest.webmanifest
tools/              make-icons.mjs, build-zip.mjs
```

## Game modes

- **Solo**: survive the waves.
- **Local multiplayer**: 2 to 4 players on one computer (WASD + Space, arrows + Enter, gamepads).
- **LAN**: one computer runs `node server.js`, everyone on the Wi-Fi joins with a room code.
- **Online**: deploy `server.js` to a Node host and share the address.

## Putting it online

Any host that runs Node.js and supports WebSockets works. For example on
Render (free tier): create a **Web Service** from this folder, build command
empty, start command `node server.js`. Then:

1. Add the site's domain in Firebase → Authentication → Settings → Authorized domains.
2. Replace `privacy@example.com` and `legal@example.com` in `privacy.html` and `terms.html`.
3. If you add or rename files, add them to `CORE` in `sw.js` and bump `VERSION`.
4. Run `node tools/build-zip.mjs` to refresh `downloads/emberwake.zip`.

## Installing the game

Players install it from the browser (Chrome, Edge, Safari "Add to Dock" or
"Add to Home Screen"). It gets its own window and icon, works offline for solo
and local play, and updates itself. No unsigned .exe, so no SmartScreen warning.
